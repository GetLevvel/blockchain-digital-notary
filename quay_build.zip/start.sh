#!/usr/bin/env bash
blockchain-digital-notary